const input = document.querySelector("input");
const form = document .querySelector("form");
const list = document .querySelector("ul");

//Add a new task
function addTask(event){
  //prevent the page from reloadng
  event.preventDefault();

  //Get the text entered by the user 
  const title = input.value.trim();

  //prevent empty tasks
  if (title==""){
    return;
  }

  //create a new list item
  const li = document.createElements("li");

  //set the task text
  li.textContent = title;

  //Add the task to the list
  list.appendChild(li);

  //clear the input field
  input.value = "";

  //focus the input again
  input.focus();
}

//listen for form submission
form.addEventListener("submit",addTask);